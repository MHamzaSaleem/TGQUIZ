﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace TakeQuizApp
{
    public partial class Selection : Form
    {
        public Selection()
        {
            InitializeComponent();
        }

        public static string name = "";
        public static string show = "";
        private void Selection_Load(object sender, EventArgs e)
        {
            button1.Visible = label2.Visible = false;    
        }

       

        private void button2_Click(object sender, EventArgs e)
        {

            if (button2.Text == "Student")
            {
                Student s = new Student();
                s.Show();
            }
            else if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Enter Your Name", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                button1.Visible = label2.Visible = true;
                label1.Location = new Point(145, 121);
                name = textBox1.Text;
                textBox1.Visible = false;
                label2.Text = "Hello " + name + "!";
                button2.Text = "Student";
                label1.Text = "Examiner Or Student?";
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //button1.Text = "Add Catgories";
            //button2.Text = "Add Question";
            //label1.Text = "Want To?";
            //label1.Location = new Point(205, 121);
            //button1.Size = new System.Drawing.Size(187,37);
            //button2.Size = new System.Drawing.Size(187, 37);
            //button1.Location = new Point(170, 170);
            //button2.Location = new Point(170, 227);
            Form1 f = new Form1();
            f.Show();
        }
    }
}
