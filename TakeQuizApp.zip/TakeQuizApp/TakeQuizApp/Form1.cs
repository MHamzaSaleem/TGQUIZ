﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TakeQuizApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Text = comboBox2.Text = "--Select--";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text==string.Empty)
            {
                DB_InteractionClass.ShowMessage("Empty");
            }
            else
            {
                DB_InteractionClass.Query = "Insert into category(Category) values('" + textBox1.Text + "')";
                DB_InteractionClass.OpenConnection();
                DB_InteractionClass.Insertion();
                DB_InteractionClass.CloseConnection();
                RefreshComboBox1();
                DB_InteractionClass.ShowMessage("Success");
                textBox1.Text = "";
            }
        }

        

        private void RefreshComboBox1()
        {
            comboBox1.Items.Clear();
            DB_InteractionClass.Query = "Select * from category";
            DB_InteractionClass.OpenConnection();
            MySqlCommand Cmd = new MySqlCommand(DB_InteractionClass.Query, DB_InteractionClass.Con);
            Cmd.CommandText = DB_InteractionClass.Query;
            DB_InteractionClass.reader = Cmd.ExecuteReader();
            while(DB_InteractionClass.reader.Read())
            {
                comboBox1.Items.Add(DB_InteractionClass.reader["category"].ToString());
            }
            DB_InteractionClass.CloseConnection();
        }
        private void RefreshComboBox2()
        {
            comboBox2.Items.Clear();
            DB_InteractionClass.Query = "Select Sub_Category from subcategory";
            DB_InteractionClass.OpenConnection();
            DB_InteractionClass.DataReader();
            while (DB_InteractionClass.reader.Read())
            {
                comboBox2.Items.Add(DB_InteractionClass.reader["Sub_Category"].ToString());
            }
            DB_InteractionClass.CloseConnection();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            label13.AutoSize = true;
            label13.Text =Selection.name+ " Welcome To Examiner Panel.";
            textBox1.Visible = textBox2.Visible = textBox3.Visible = textBox4.Visible = textBox5.Visible = textBox6.Visible = false;
            label1.Visible = label2.Visible = label3.Visible = label4.Visible = label5.Visible = label6.Visible = label7.Visible = label8.Visible = label9.Visible = label10.Visible = label11.Visible = false;
            comboBox1.Visible = comboBox2.Visible = false;
            button1.Visible = button2.Visible = button3.Visible =button6.Visible = false;
            RefreshComboBox1();
            RefreshComboBox2();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex < 0 && textBox2.Text == string.Empty)
            {
                DB_InteractionClass.ShowMessage("both");
            }
            else if(textBox2.Text==string.Empty)
            {
                DB_InteractionClass.ShowMessage("Empty");
            }
            else if(comboBox1.SelectedIndex < 0)
            {
                DB_InteractionClass.ShowMessage("Combo");
            }
            else 
            {
                DB_InteractionClass.Query = "insert into subcategory(Sub_Category,ID) values('" + textBox2.Text + "',(select ID from category where Category = '" + comboBox1.Text + "'))";
                DB_InteractionClass.OpenConnection();
                DB_InteractionClass.Insertion();
                RefreshComboBox2();
                DB_InteractionClass.CloseConnection();
                DB_InteractionClass.ShowMessage("Success");
            }
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == string.Empty || textBox4.Text == string.Empty || textBox5.Text == string.Empty || textBox6.Text == string.Empty)
            {
                DB_InteractionClass.ShowMessage("morethanone");
            }
            else if (comboBox2.SelectedIndex<0)
            {
                DB_InteractionClass.ShowMessage("Combo");
            }
            else if (comboBox2.SelectedIndex < 0 && textBox3.Text == string.Empty || textBox4.Text == string.Empty || textBox5.Text == string.Empty || textBox6.Text == string.Empty)
            {
                DB_InteractionClass.ShowMessage("both");
            }
            else if(!textBox4.Text.Contains(','))
            {
                DB_InteractionClass.ShowMessage("CheckHintsFormat");
            }
            else
            {
                DB_InteractionClass.Query = "insert into question(Question,Hints,Answer,Example,S_ID) values('" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "',(select S_ID from subcategory where Sub_Category = '" + comboBox2.Text + "'))";
                DB_InteractionClass.OpenConnection();
                DB_InteractionClass.Insertion();
                DB_InteractionClass.CloseConnection();
                DB_InteractionClass.ShowMessage("Success");
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = "";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Visible = label11.Visible = label2.Visible = label4.Visible = label5.Visible = true;
            button1.Visible = button2.Visible = button6.Visible = true;
            button4.Visible = button5.Visible = label12.Visible= false;
            comboBox1.Visible = true;
            textBox1.Visible = textBox2.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Visible = label11.Visible = label2.Visible = label4.Visible = label5.Visible = false;
            button1.Visible = button2.Visible = button4.Visible = button5.Visible = label12.Visible = false;
            comboBox1.Visible = false;
            textBox1.Visible = textBox2.Visible = false;
            button6.Visible = textBox3.Visible=textBox4.Visible=textBox5.Visible=textBox6.Visible=comboBox2.Visible= true;
            label3.Visible = label6.Visible = label7.Visible = label8.Visible = label9.Visible = label10.Visible = button3.Visible = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Visible = textBox2.Visible = textBox3.Visible = textBox4.Visible = textBox5.Visible = textBox6.Visible = false;
            label1.Visible = label2.Visible = label3.Visible = label4.Visible = label5.Visible = label6.Visible = label7.Visible = label8.Visible = label9.Visible = label10.Visible = label11.Visible = false;
            comboBox1.Visible = comboBox2.Visible = false;
            button1.Visible = button2.Visible = button3.Visible = button6.Visible= false;
            button4.Visible = button5.Visible =label12.Visible = true;
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
