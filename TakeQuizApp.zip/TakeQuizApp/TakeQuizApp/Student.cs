﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace TakeQuizApp
{
    public partial class Student : Form
    {
        
        string CurrentCategory="";
        string CurrentSubCategory = "";
        int limit, Score = 0, listlength = 0, temp = 0;
        public static int totalQuestions=0;
        List<QuestionList> QuestionsList = new List<QuestionList>();
        public Student()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CurrentCategory = comboBox1.Text;
            GetSubCategoryList();
        }

       

        private void Student_Load(object sender, EventArgs e)
        {
            comboBox1.Text = comboBox2.Text = "--Select--";
            label9.Text = "Which Category Questions Do You want to Solve?";
            label8.Text = "Hello "+ Selection.name + ", Welcome To Student's Panel.";
            GetCategoryList();
            checkBox1.Hide();
            textBox1.Hide();
            button4.Enabled = false;
            button2.Visible = label3.Visible = label4.Visible = label5.Visible = label6.Visible = button3.Visible = button4.Visible = radioButton1.Visible = radioButton2.Visible = radioButton3.Visible = radioButton4.Visible = label7.Visible = button5.Visible= false;
        }
        private void GetCategoryList()
        {
            comboBox1.Items.Clear();
            DB_InteractionClass.Query = "Select * from category";
            DB_InteractionClass.OpenConnection();
            DB_InteractionClass.DataReader();
            while (DB_InteractionClass.reader.Read())
            {
                comboBox1.Items.Add(DB_InteractionClass.reader["category"].ToString());
            }

            DB_InteractionClass.CloseConnection();
        }
        private void GetSubCategoryList()
        {
            comboBox2.Items.Clear();
            DB_InteractionClass.Query = "Select * from subcategory  where ID = (select ID from category where Category = '" + CurrentCategory + "')";
            DB_InteractionClass.OpenConnection();
            DB_InteractionClass.DataReader();
            while (DB_InteractionClass.reader.Read())
            {
                comboBox2.Items.Add(DB_InteractionClass.reader["Sub_Category"].ToString());
            }
            DB_InteractionClass.CloseConnection();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex<0 || comboBox2.SelectedIndex<0)
            {
                DB_InteractionClass.ShowMessage("Combo");
            }
            else 
            {
                label9.Text = "How Much Questions Do You Want To Solve?";
                label9.Location = new System.Drawing.Point(50, 143);
                label1.Text = "Set Questions Limit";
                label2.Hide();
                comboBox1.Hide();
                comboBox2.Hide();
                button1.Hide();
                button2.Visible = true;
                checkBox1.Visible = true;
                textBox1.Visible = button5.Visible = true;
                DB_InteractionClass.OpenConnection();
                DB_InteractionClass.Query = "Select question from question  where S_ID = (select S_ID from subcategory where Sub_Category = '"+comboBox2.Text+"')";
                DB_InteractionClass.DataReader();
                while (DB_InteractionClass.reader.Read())
                {
                    totalQuestions++; 
                }
                DB_InteractionClass.CloseConnection();
                CurrentSubCategory = comboBox2.Text;
            }
        }
        
        private void button2_Click(object sender, EventArgs e)

            {
            if(checkBox1.Checked==true)
            {
                DB_InteractionClass.Query = "select * from Question where S_ID=(select S_ID from subcategory where Sub_Category = '" + CurrentSubCategory + "')";
                DB_InteractionClass.OpenConnection();
                DB_InteractionClass.DataReader();
                GetList();
                DB_InteractionClass.CloseConnection();
                GetQuestion();
                limit = totalQuestions;
                Button2Disabled();
                button5.Visible = false;
            }
            else
            { 
                if(textBox1.Text != "")
                { 
                    limit = Convert.ToInt32(textBox1.Text);
                    if (limit < totalQuestions)
                    {
                        DB_InteractionClass.Query = "select * from Question where S_ID=(select S_ID from subcategory where Sub_Category = '" + CurrentSubCategory + "') order by rand() limit " + limit + "";
                        DB_InteractionClass.OpenConnection();
                        DB_InteractionClass.DataReader();
                        GetList();
                        DB_InteractionClass.CloseConnection();
                        Button2Disabled();
                        GetQuestion();
                        button5.Visible = false;
                    }
                    else
                    {
                        DB_InteractionClass.ShowMessage("QuestionsLimit");
                    }
                }
                else
                {
                    DB_InteractionClass.ShowMessage("Enter");
                }
            }
            textBox1.Text = "";
        }

        private void Button2Disabled()
        {
            button2.Visible = textBox1.Visible = checkBox1.Visible = label1.Visible = label9.Visible= false;
            radioButton1.Visible = radioButton2.Visible = radioButton3.Visible = radioButton4.Visible = label3.Visible = label4.Visible = label5.Visible = label6.Visible = button3.Visible = button4.Visible =label7.Visible = true;
        }

        private void GetList()
        {
            while (DB_InteractionClass.reader.Read())
            {
                listlength++;
                QuestionsList.Add(new QuestionList()
                {
                    Q_ID = Convert.ToInt32(DB_InteractionClass.reader[0]),
                    Question = DB_InteractionClass.reader[1].ToString(),
                    Hints = DB_InteractionClass.reader[2].ToString(),
                    Answer = DB_InteractionClass.reader[3].ToString(),
                    Example = DB_InteractionClass.reader[4].ToString(),
                    S_ID = Convert.ToInt32(DB_InteractionClass.reader[5])
                });
            }
            temp = listlength;
        }

        private void GetQuestion()
        {
            
            if(listlength!=0)
            {
                label4.Text = QuestionsList[temp-listlength].Question;
                string HintsList = QuestionsList[temp - listlength].Hints;
                string[] HintsArray = HintsList.Split(',');
                radioButton1.Text = HintsArray[0].ToString();
                radioButton2.Text = HintsArray[1].ToString();
                radioButton3.Text = HintsArray[2].ToString();
                radioButton4.Text = HintsArray[3].ToString();
                listlength--;
            }
            else
            {
                radioButton1.Visible = radioButton2.Visible = radioButton3.Visible = radioButton4.Visible = button4.Visible=button3.Visible=label5.Visible=label7.Visible=label6.Visible=label4.Visible= false;
                label3.Location = new System.Drawing.Point(175,191);
                label3.Text = "Your Score is " + Score + "!";
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                textBox1.Enabled = false;
            }
            else
            {

                textBox1.Enabled = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            StartAgain();
        }

        private void StartAgain()
        {
            label1.Text = "Select Category";
            label9.Text = "Which Category Questions Do You want to Solve?";
            button2.Visible = false;
            checkBox1.Visible = false;
            textBox1.Visible = false;
            comboBox1.Visible = comboBox2.Visible = label2.Visible = button1.Visible = true;
            comboBox2.Text = comboBox1.Text = "--Select--";
        }
        

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            label5.Visible = label6.Visible = false;
            GetQuestion();
            button3.Enabled = true;
            button4.Enabled = false;
            radioButton1.Checked = radioButton2.Checked=radioButton3.Checked=radioButton4.Checked= false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label6.Visible = label5.Visible = true;
            if(!radioButton1.Checked&&!radioButton2.Checked&&!radioButton3.Checked&&!radioButton4.Checked)
            {
                button3.Enabled = true;
                button4.Enabled = false;
                DB_InteractionClass.ShowMessage("ValidateRadioButton");
            }
            if (radioButton1.Checked)
            {
                if(QuestionsList[(temp-listlength)-1].Answer.Equals(radioButton1.Text))
                {
                    label7.Text = ("Score : "+ ++Score).ToString();
                    label5.Text = "Correct!";
                }
                else
                {
                    label5.Text = "Wrong! The answer is " + QuestionsList[(temp-listlength)-1].Answer;
                }
                button3.Enabled = false;
                button4.Enabled = true;
            }
            else if(radioButton2.Checked)
            {
                if (QuestionsList[(temp - listlength)-1].Answer.Equals(radioButton2.Text))
                {
                    label7.Text = ("Score : " + ++Score).ToString();
                    label5.Text = "Correct!";
                }
                else
                {
                    label5.Text = "Wrong! The answer is " + QuestionsList[(temp - listlength) - 1].Answer;
                }
                button3.Enabled = false;
                button4.Enabled = true;
            }
            else if (radioButton3.Checked)
            {
                if (QuestionsList[(temp - listlength)-1].Answer.Equals(radioButton3.Text))
                {
                    label7.Text = ("Score : " + ++Score).ToString();
                    label5.Text = "Correct!";
                }
                else
                {
                    label5.Text = "Wrong! The answer is " + QuestionsList[(temp - listlength) - 1].Answer;
                }
                button3.Enabled = false;
                button4.Enabled = true;
            }
            else if (radioButton4.Checked)
            {
                if (QuestionsList[(temp - listlength)-1].Answer.Equals(radioButton4.Text))
                {
                    label7.Text = ("Score : " + ++Score).ToString();
                    label5.Text = "Correct!";
                }
                else
                {
                    label5.Text = "Wrong! The answer is " + QuestionsList[(temp - listlength) - 1].Answer;
                }
                button3.Enabled = false;
                button4.Enabled = true;
            }
            limit--;
            if (limit == 0)
            {
                button4.Text = "Result";
            }
            label6.Text = QuestionsList[(temp - listlength)-1].Example;
        }
    }
}
