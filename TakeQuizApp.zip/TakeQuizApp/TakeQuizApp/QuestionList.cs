﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TakeQuizApp
{
    class QuestionList
    {
            public int Q_ID { get; set; }
            public string Question { get; set; }
            public string Hints { get; set; }
            public string Answer { get; set; }
            public string Example { get; set; }
            public int S_ID { get; set; }
        
    }
}
