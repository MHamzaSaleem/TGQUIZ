﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace TakeQuizApp
{
    public static class DB_InteractionClass
    {
        public static string ConString = ConfigurationManager.ConnectionStrings["TakeQuizApp.Properties.Settings.Setting"].ToString();
        public static MySqlConnection Con;
        public static MySqlDataReader reader;
        public static string Query ="";
        public static void OpenConnection()
        {
            Con = new MySqlConnection(ConString);
            Con.Open();
        }
        public static void DataReader()
        {
            MySqlCommand Cmd = new MySqlCommand(Query, Con);
            Cmd.CommandText = Query;
            reader = Cmd.ExecuteReader();
        }
        public static void CloseConnection()
        {
            Con.Close();
        }
        public static void Insertion()
        {
            MySqlCommand Cmd = new MySqlCommand(Query, Con);
            Cmd.ExecuteNonQuery();
            Query = "";
        }

        public static void ShowMessage(string msg)
        {
            if (msg.Equals("Empty"))
            {
                MessageBox.Show("Enter Category Name!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("Combo"))
            {
                MessageBox.Show("Category is not Selected!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("norethanone"))
            {
                MessageBox.Show("Some Fields are Empty!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("both"))
            {
                MessageBox.Show("Fields are empty and not selected!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("Enter"))
            {
                MessageBox.Show("Enter Some Limits To Continue!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("CheckHintsFormat"))
            {
                MessageBox.Show("Hints Should be in Comma Separated Form!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("QuestionsLimit"))
            {
                MessageBox.Show("Limit Should less than total no of questions, Total Questions "+Student.totalQuestions, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("ValidateRadioButton"))
            {
                MessageBox.Show("Select 1 Answer To Continue!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (msg.Equals("Success"))
            {
                MessageBox.Show("Inserted Successfully!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}

